<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "rrr";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
  $id = $_GET['id'];
  $sql = "SELECT * FROM deals WHERE id='$id'";
  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
    $deal = $result->fetch_assoc();
    echo json_encode($deal);
  } else {
    echo "Error: Deal not found";
  }
}

$conn->close();
?>
